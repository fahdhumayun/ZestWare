var searchData=
[
  ['if',['if',['../get_employee_info_8php.html#af9ff86dbcf946c2682f6c9ae6dc2c685',1,'if():&#160;getEmployeeInfo.php'],['../inventory_index_8php.html#af9ff86dbcf946c2682f6c9ae6dc2c685',1,'if():&#160;inventoryIndex.php']]]
];
