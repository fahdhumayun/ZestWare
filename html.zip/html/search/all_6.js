var searchData=
[
  ['readme_2emd',['README.md',['../startbootstrap-simple-sidebar-gh-pages_2_r_e_a_d_m_e_8md.html',1,'(Global Namespace)'],['../_r_e_a_d_m_e_8md.html',1,'(Global Namespace)']]]
];
