var searchData=
[
  ['getemployeeinfo_2ephp',['getEmployeeInfo.php',['../get_employee_info_8php.html',1,'']]],
  ['group_20_23_208_20_2d_20restaurant_20automation',['Group # 8 - Restaurant Automation',['../md__c_1_xampp_htdocs__r_e_a_d_m_e.html',1,'']]]
];
