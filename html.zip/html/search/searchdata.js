var indexSectionsWithContent =
{
  0: "$aegilrsw",
  1: "aegilrs",
  2: "$eiw",
  3: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "variables",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Variables",
  3: "Pages"
};

